const toggle = document.getElementById('menu-toggle');
const menu = document.getElementById('menu-overlay');

// Abre/fecha ao clicar no ícone
toggle.addEventListener('click', (event) => {
    event.stopPropagation(); // Impede o clique de subir e acionar o fechamento
    menu.classList.toggle('open');
});

// Fecha ao pressionar ESC
document.addEventListener('keydown', (event) => {
    if (event.key === "Escape" && menu.classList.contains('open')) {
        menu.classList.remove('open');
    }
});

// Fecha ao clicar fora do menu
document.addEventListener('click', (event) => {
    const isClickInsideMenu = menu.contains(event.target) || toggle.contains(event.target);
    if (!isClickInsideMenu && menu.classList.contains('open')) {
        menu.classList.remove('open');
    }
});
